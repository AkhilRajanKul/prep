"""
stringeex_service.py
All communication with the StringeeX API lives here.
"""

import requests
import logging
from datetime import datetime, timedelta, timezone
from django.conf import settings

logger = logging.getLogger(__name__)


class StringeeXError(Exception):
    pass


def get_auth_token() -> tuple[str, str]:
    """
    Authenticate with StringeeX and return (token, portal_base_url).
    """
    portal   = settings.STRINGEEX_PORTAL
    base_url = f"https://{portal}.stringeex.com"
    url      = f"{base_url}/v1/account"

    payload = {
        "email":    settings.STRINGEEX_EMAIL,
        "password": settings.STRINGEEX_PASSWORD,
    }

    try:
        resp = requests.post(url, json=payload, timeout=15)
        resp.raise_for_status()
    except requests.RequestException as e:
        raise StringeeXError(f"Login request failed: {e}") from e

    data = resp.json()
    if data.get('r') != 0:
        raise StringeeXError(f"API login error: {data}")

    portals = data.get('portals', [])
    portal_domain = base_url.split("://")[-1]

    token = None
    for p in portals:
        if p.get('domain') == portal_domain:
            token = p.get('auth_token')
            break

    if not token and portals:
        token = portals[0].get('auth_token')

    if not token:
        raise StringeeXError("No auth token found in login response")

    logger.info("StringeeX auth OK — portal: %s", portal)
    return token, base_url


def fetch_calls_for_range(token: str, base_url: str,
                          start_dt: datetime, end_dt: datetime,
                          page_size: int = 1000) -> list[dict]:
    """
    Fetch all call records between start_dt and end_dt (timezone-aware datetimes).
    Handles pagination automatically.
    """
    url     = f"{base_url}/v1/call/history"
    headers = {"X-STRINGEE-AUTH": token, "Content-Type": "application/json"}

    start_ms = int(start_dt.timestamp() * 1000)
    end_ms   = int(end_dt.timestamp() * 1000)

    all_rows = []
    page = 1

    while True:
        params = {
            "limit":      page_size,
            "page":       page,
            "start_time": start_ms,
            "end_time":   end_ms,
        }

        try:
            resp = requests.get(url, headers=headers, params=params, timeout=20)
            resp.raise_for_status()
        except requests.RequestException as e:
            raise StringeeXError(f"Call history request failed: {e}") from e

        data = resp.json()
        if data.get('r') != 0:
            raise StringeeXError(f"API error fetching history: {data}")

        rows  = data.get('data', {}).get('rows', [])
        total = data.get('data', {}).get('totalCount', 0)

        all_rows.extend(rows)
        logger.info("Page %d — fetched %d / %d records", page, len(all_rows), total)

        # Stop if we have everything or got an empty page
        if len(all_rows) >= total or not rows:
            break

        page += 1

    return all_rows


def fetch_recent_calls(hours_back: int = 2) -> list[dict]:
    """
    Convenience wrapper used by the live-sync scheduler.
    Returns records from the last `hours_back` hours.
    """
    token, base_url = get_auth_token()
    now   = datetime.now(tz=timezone.utc)
    start = now - timedelta(hours=hours_back)
    return fetch_calls_for_range(token, base_url, start, now)
