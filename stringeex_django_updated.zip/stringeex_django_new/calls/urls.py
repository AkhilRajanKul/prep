from django.urls import path
from . import views

urlpatterns = [
    path('',                       views.dashboard,           name='dashboard'),
    path('api/stats/',             views.api_stats,           name='api_stats'),
    path('api/calls/',             views.api_calls,           name='api_calls'),
    path('api/agent-summary/',     views.api_agent_summary,   name='api_agent_summary'),
    path('api/hourly-breakdown/',  views.api_hourly_breakdown, name='api_hourly_breakdown'),
    path('api/team-list/',         views.api_team_list,       name='api_team_list'),
    path('api/last-sync/',         views.api_last_sync,       name='api_last_sync'),
]
