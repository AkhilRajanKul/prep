"""
team_lookup.py
--------------
Loads the Team_tradex.xlsx (Sheet2) and builds a fast dict keyed by
the Stringee "Dialer Name" column (agent email used in the API).

Usage:
    from calls.team_lookup import get_team_lookup
    lookup = get_team_lookup()          # dict keyed by lowercase email
    info   = lookup.get('anushka@bluewave.com')
    # -> {'full_name': 'Anushka', 'employee_code': 'E-XXXX', ...}

The lookup is built once at import time and cached in memory.
Call reload_team_lookup() after updating the xlsx to refresh.
"""

import os
import logging
import pandas as pd

logger = logging.getLogger(__name__)

# Path to the team list (place in project root or set via env var)
_DEFAULT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)),
    'data',
    'Team_tradex.xlsx',
)
TEAM_XLSX_PATH = os.environ.get('TEAM_XLSX_PATH', _DEFAULT_PATH)

_CACHE: dict | None = None


def _build_lookup(path: str) -> dict:
    """
    Read the Stringee rows from Team_tradex.xlsx and return a dict:
        { 'anushka@bluewave.com': { full_name, employee_code, pool, tl, vertical } }
    """
    try:
        df = pd.read_excel(path, sheet_name='Sheet2')
    except FileNotFoundError:
        logger.warning("Team xlsx not found at %s — agent enrichment disabled.", path)
        return {}
    except Exception as exc:
        logger.error("Failed to read team xlsx: %s", exc)
        return {}

    # Only keep Stringee rows (case-insensitive)
    df = df[df['Dialer'].str.strip().str.lower() == 'stringee'].copy()

    lookup = {}
    for _, row in df.iterrows():
        dialer_name = str(row.get('Dialer Name', '')).strip().lower()
        if not dialer_name:
            continue

        def _clean(val):
            v = str(val).strip()
            return '' if v in ('#N/A', 'nan', 'None') else v

        lookup[dialer_name] = {
            'full_name':     _clean(row.get('Full Name', '')),
            'employee_code': _clean(row.get('Employee code', '')),
            'pool':          _clean(row.get('Pool', '')),
            'tl':            _clean(row.get('TL', '')),
            'vertical':      _clean(row.get('Vertical', '')),
        }

    logger.info("Team lookup built — %d Stringee agents loaded.", len(lookup))
    return lookup


def get_team_lookup() -> dict:
    """Return the cached lookup dict, building it on first call."""
    global _CACHE
    if _CACHE is None:
        _CACHE = _build_lookup(TEAM_XLSX_PATH)
    return _CACHE


def reload_team_lookup() -> dict:
    """Force a reload from disk (call after xlsx updates)."""
    global _CACHE
    _CACHE = _build_lookup(TEAM_XLSX_PATH)
    return _CACHE


def enrich_record(account_name: str | None) -> dict:
    """
    Given an account_name (e.g. 'anushka@bluewave.com'), return the
    matching team metadata dict, or empty strings for all fields.
    """
    lookup = get_team_lookup()
    key = (account_name or '').strip().lower()
    return lookup.get(key, {
        'full_name': '', 'employee_code': '',
        'pool': '', 'tl': '', 'vertical': '',
    })
