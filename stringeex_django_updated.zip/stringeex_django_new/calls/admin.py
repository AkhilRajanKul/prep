from django.contrib import admin
from .models import CallRecord


@admin.register(CallRecord)
class CallRecordAdmin(admin.ModelAdmin):
    list_display  = ('id', 'direction', 'customer_number', 'account_name',
                      'duration_display', 'end_call_reason', 'fetched_at')
    list_filter   = ('direction', 'end_call_reason')
    search_fields = ('customer_number', 'account_name', 'stringee_number')
    readonly_fields = ('id', 'fetched_at')
    ordering      = ('-start_time_ms',)

    def duration_display(self, obj):
        return obj.duration_display
    duration_display.short_description = 'Talk Duration'
