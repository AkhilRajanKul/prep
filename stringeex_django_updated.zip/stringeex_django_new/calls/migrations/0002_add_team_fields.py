"""
Migration: add team-enrichment fields to CallRecord.
Also converts answer_duration to FloatField (was IntegerField).
"""

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('calls', '0001_initial'),
    ]

    operations = [
        # Change answer_duration to FloatField to accept null/NaN from new CSV
        migrations.AlterField(
            model_name='callrecord',
            name='answer_duration',
            field=models.FloatField(default=0),
        ),
        # Team enrichment fields
        migrations.AddField(
            model_name='callrecord',
            name='full_name',
            field=models.CharField(blank=True, max_length=255, null=True),
        ),
        migrations.AddField(
            model_name='callrecord',
            name='employee_code',
            field=models.CharField(blank=True, max_length=64, null=True),
        ),
        migrations.AddField(
            model_name='callrecord',
            name='pool',
            field=models.CharField(blank=True, max_length=128, null=True),
        ),
        migrations.AddField(
            model_name='callrecord',
            name='tl',
            field=models.CharField(blank=True, max_length=128, null=True),
        ),
        migrations.AddField(
            model_name='callrecord',
            name='vertical',
            field=models.CharField(blank=True, max_length=128, null=True),
        ),
    ]
